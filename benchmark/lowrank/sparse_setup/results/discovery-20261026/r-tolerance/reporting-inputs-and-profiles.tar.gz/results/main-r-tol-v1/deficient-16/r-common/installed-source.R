function (Y, X, nrank = 2, method = c("glasso", "adglasso"), 
    ic.type = c("BIC", "BICP", "AIC", "GCV", "GIC"), A0 = NULL, 
    V0 = NULL, modstr = list(), control = list(), screening = FALSE) 
{
    Call <- match.call()
    method <- match.arg(method)
    ic <- match.arg(ic.type)
    p <- ncol(X)
    q <- ncol(Y)
    n <- nrow(Y)
    if (n != nrow(X)) 
        stop("'nrow(X)' has to be equal to 'nrow(Y)'.")
    if (screening) {
        ini.screen <- glm.screen(Y, X)
        p.index <- ini.screen$p.index
        q.index <- ini.screen$q.index
        Yorg <- Y
        Xorg <- X
        porg <- p
        qorg <- q
        Y <- Y[, q.index]
        X <- X[, p.index]
        q <- length(q.index)
        p <- length(p.index)
    }
    control <- do.call("srrr.control", control)
    modstr <- do.call("srrr.modstr", modstr)
    nlam <- modstr$nlam
    lamA <- modstr$lamA
    minLambda <- modstr$minLambda
    maxLambda <- modstr$maxLambda
    WA <- modstr$WA
    wgamma <- modstr$wgamma
    epsilon <- control$epsilon
    maxit <- control$maxit
    inner.eps <- control$inner.eps
    inner.maxit <- control$inner.maxit
    ICpath <- array(NA, dim = c(nlam, 5))
    Apath <- array(NA, dim = c(nlam, p, nrank))
    Vpath <- array(NA, dim = c(nlam, q, nrank))
    if (is.null(V0) | is.null(A0)) {
        ini <- rrr.fit(Y, X, nrank = nrank, coefSVD = TRUE)
        V0 <- ini$coefSVD$v
        A0 <- ini$coefSVD$u * ini$coefSVD$d
    }
    else {
        ini <- NULL
        C0 <- A0 %*% t(V0)
    }
    if (is.null(WA)) {
        if (is.null(ini)) 
            ini <- rrr.fit(Y, X, nrank = nrank, coefSVD = TRUE)
        WA <- switch(method, glasso = rep(1, p), adglasso = apply(ini$coef, 
            1, function(a) sqrt(sum(a^2)))^{
            -wgamma
        })
    }
    if (is.null(lamA)) {
        if (is.null(ini)) 
            ini <- rrr.fit(Y, X, nrank = nrank, coefSVD = TRUE)
        if (is.null(maxLambda)) 
            maxLambda <- max(apply(ini$coef, 1, function(a) sqrt(sum(a^2)))/WA) * 
                2
        if (is.null(minLambda)) 
            minLambda <- maxLambda * 1e-04
        if (is.null(nlam)) 
            nlam <- 20
        lamA <- c(0, exp(seq(log(minLambda), log(maxLambda), 
            length = nlam - 1)))
    }
    YX <- crossprod(Y, X)
    Apath[1, , ] <- A0
    Vpath[1, , ] <- V0
    h <- 1
    for (l in seq_len(nlam)) {
        A0 <- as.matrix(Apath[ifelse(h > 1, h - 1, 1), , ])
        V0 <- as.matrix(Vpath[ifelse(h > 1, h - 1, 1), , ])
        h <- h + 1
        fit <- srrr_Rcpp(Y, X, method, A0, V0, nrank, lamA[l], 
            epsilon, maxit, inner.eps, inner.maxit, WA)
        A0 <- fit$A
        V0 <- fit$V
        Apath[l, , ] <- A0
        Vpath[l, , ] <- V0
        ICpath[l, 1] <- fit$BIC
        ICpath[l, 2] <- fit$BICP
        ICpath[l, 3] <- fit$AIC
        ICpath[l, 4] <- fit$GCV
        ICpath[l, 5] <- fit$GIC
    }
    minid <- apply(ICpath, 2, which.min)
    ICid <- switch(ic, BIC = minid[1], BICP = minid[2], AIC = minid[3], 
        GCV = minid[4], GIC = minid[5])
    A <- as.matrix(Apath[ICid, , ])
    d <- apply(A, 2, function(a) sqrt(sum(a^2)))
    if (screening) {
        U.reduced <- A %*% diag(1/d, nrow = nrank, ncol = nrank)
        V.reduced <- Vpath[ICid, , ]
        coef.reduced <- A %*% t(V.reduced)
        U <- matrix(nrow = porg, ncol = nrank, 0)
        U[p.index, ] <- U.reduced
        V <- matrix(nrow = qorg, ncol = nrank, 0)
        V[q.index, ] <- V.reduced
        D <- diag(d, nrow = nrank, ncol = nrank)
        coefMat <- matrix(nrow = porg, ncol = qorg, 0)
        coefMat[p.index, q.index] <- coef.reduced
    }
    else {
        D <- diag(d, nrow = nrank, ncol = nrank)
        U <- A %*% diag(1/d, nrow = nrank, ncol = nrank)
        V <- Vpath[ICid, , ]
        coefMat <- A %*% t(V)
        p.index <- NULL
        q.index <- NULL
    }
    out <- list(call = Call, Y = Y, X = X, p.index = p.index, 
        q.index = q.index, A.path = Apath, V.path = Vpath, ic.path = ICpath, 
        lambda = lamA, minid = minid, coef = coefMat, U = U, 
        V = V, D = D, rank = nrank)
    class(out) <- "srrr"
    out
}
<bytecode: 0xce15920>
<environment: namespace:rrpack>
function (Y, X, method, A0, V0, nrank, lambda, conv, maxiter, 
    inner_conv, inner_iter, WA) 
{
    .Call("_rrpack_srrr_Rcpp", PACKAGE = "rrpack", Y, X, method, 
        A0, V0, nrank, lambda, conv, maxiter, inner_conv, inner_iter, 
        WA)
}
<bytecode: 0xe230908>
<environment: namespace:rrpack>
function (Y, X, nrank = 1, weight = NULL, coefSVD = FALSE) 
{
    Call <- match.call()
    q <- ncol(Y)
    n <- nrow(Y)
    p <- ncol(X)
    stopifnot(n == nrow(X))
    S_yx <- crossprod(Y, X)
    S_xx <- crossprod(X)
    S_xx_inv <- tryCatch(ginv(S_xx), error = function(e) solve(S_xx + 
        0.1 * diag(p)))
    C_ls <- tcrossprod(S_xx_inv, S_yx)
    if (!is.null(weight)) {
        stopifnot(nrow(weight) == q && ncol(weight) == q)
        eigenGm <- eigen(weight)
        sqrtGm <- eigenGm$vectors %*% (sqrt(eigenGm$values) * 
            t(eigenGm$vectors))
        sqrtinvGm <- eigenGm$vectors %*% (1/sqrt(eigenGm$values) * 
            t(eigenGm$vectors))
        XC <- X %*% C_ls %*% sqrtGm
        svdXC <- svd(XC, nrank, nrank)
        A <- svdXC$v[, 1:nrank]
        Ad <- (svdXC$d[1:nrank])^2
        AA <- tcrossprod(A)
        C_rr <- C_ls %*% sqrtGm %*% AA %*% sqrtinvGm
    }
    else {
        XC <- X %*% C_ls
        svdXC <- svd(XC, nrank, nrank)
        A <- svdXC$v[, 1:nrank]
        Ad <- (svdXC$d[1:nrank])^2
        AA <- tcrossprod(A)
        C_rr <- C_ls %*% AA
    }
    ret <- list(call = Call, coef = C_rr, coef.ls = C_ls, fitted = X %*% 
        C_rr, fitted.ls = XC, A = A, Ad = Ad, rank = nrank)
    if (coefSVD) {
        coefSVD <- svd(C_rr, nrank, nrank)
        coefSVD$d <- coefSVD$d[1:nrank]
        coefSVD$u <- coefSVD$u[, 1:nrank, drop = FALSE]
        coefSVD$v <- coefSVD$v[, 1:nrank, drop = FALSE]
        ret <- c(ret, list(coefSVD = coefSVD))
    }
    class(ret) <- "rrr.fit"
    ret
}
<bytecode: 0xcdcad08>
<environment: namespace:rrpack>
