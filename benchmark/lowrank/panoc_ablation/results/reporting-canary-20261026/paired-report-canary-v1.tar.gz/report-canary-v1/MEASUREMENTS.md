# Replicated nuclear PANOC measurements

Complete processes: 30/30; certificates: 660; failed certificates: 0.

Each independent input contributes one median of three warmed timing rounds. Ratios below one favor the numerator. The 95% interval uses Student t on paired log ratios and estimates a geometric mean ratio; rounds are not additional independent inputs. Intervals are descriptive and not adjusted for multiple comparisons.

All candidates and complete-result comparators include returned diagnostics. The coefficient-only control omits those fields and is attribution evidence only. Public and common cached workloads are reported separately. Public native paths include the same minimal complete-solution extraction adapter before and after.

| Case | Comparison | Workload | Inputs | Numerator s | Denominator s | Median ratio | Paired range | Geomean 95% interval |
|---|---|---|---:|---:|---:|---:|---|---|
| medium | cadence1/pb95 | cold | 1 | 0.0225 | 0.016262 | 1.3835 | 1.3835–1.3835 | —–— |
| medium | cadence1/pb95 | path | 1 | 0.15787 | 0.1289 | 1.2247 | 1.2247–1.2247 | —–— |
| medium | cadence20/pb95 | cold | 1 | 0.015907 | 0.016262 | 0.97811 | 0.97811–0.97811 | —–— |
| medium | cadence20/pb95 | path | 1 | 0.1276 | 0.1289 | 0.98993 | 0.98993–0.98993 | —–— |
| medium | candidate/apg | cold | 1 | 0.013509 | 0.02371 | 0.56976 | 0.56976–0.56976 | —–— |
| medium | candidate/apg | path | 1 | 0.10474 | 0.15796 | 0.66309 | 0.66309–0.66309 | —–— |
| medium | candidate/baseline | cold | 1 | 0.013509 | 0.016001 | 0.84428 | 0.84428–0.84428 | —–— |
| medium | candidate/baseline | path | 1 | 0.10474 | 0.12756 | 0.82108 | 0.82108–0.82108 | —–— |
| medium | candidate/guarded_final | cold | 1 | 0.013509 | 0.014017 | 0.96375 | 0.96375–0.96375 | —–— |
| medium | candidate/guarded_final | path | 1 | 0.10474 | 0.10554 | 0.99247 | 0.99247–0.99247 | —–— |
| medium | candidate/po95 | cold | 1 | 0.013509 | 0.016761 | 0.806 | 0.806–0.806 | —–— |
| medium | candidate/po95 | path | 1 | 0.10474 | 0.13134 | 0.79747 | 0.79747–0.79747 | —–— |
| medium | candidate/py_admm | cold | 1 | 0.013509 | 0.046776 | 0.28881 | 0.28881–0.28881 | —–— |
| medium | candidate/py_admm | path | 1 | 0.10474 | 0.32276 | 0.32451 | 0.32451–0.32451 | —–— |
| medium | candidate/py_fista | cold | 1 | 0.013509 | 0.050852 | 0.26566 | 0.26566–0.26566 | —–— |
| medium | candidate/py_fista | path | 1 | 0.10474 | 0.32043 | 0.32687 | 0.32687–0.32687 | —–— |
| medium | coeffonly/pb95 | cold | 1 | 0.015066 | 0.016262 | 0.9264 | 0.9264–0.9264 | —–— |
| medium | coeffonly/pb95 | path | 1 | 0.13238 | 0.1289 | 1.027 | 1.027–1.027 | —–— |
| medium | finalreuse/pb95 | cold | 1 | 0.015791 | 0.016262 | 0.97103 | 0.97103–0.97103 | —–— |
| medium | finalreuse/pb95 | path | 1 | 0.12339 | 0.1289 | 0.9572 | 0.9572–0.9572 | —–— |
| medium | guarded/pb95 | cold | 1 | 0.013907 | 0.016262 | 0.85517 | 0.85517–0.85517 | —–— |
| medium | guarded/pb95 | path | 1 | 0.10727 | 0.1289 | 0.83217 | 0.83217–0.83217 | —–— |
| medium | guarded_final/pb95 | cold | 1 | 0.014017 | 0.016262 | 0.86195 | 0.86195–0.86195 | —–— |
| medium | guarded_final/pb95 | path | 1 | 0.10554 | 0.1289 | 0.81872 | 0.81872–0.81872 | —–— |
| medium | pb95/baseline | cold | 1 | 0.016262 | 0.016001 | 1.0163 | 1.0163–1.0163 | —–— |
| medium | pb95/baseline | path | 1 | 0.1289 | 0.12756 | 1.0105 | 1.0105–1.0105 | —–— |
| medium | pb99_safe/pb95 | cold | 1 | 0.01613 | 0.016262 | 0.99183 | 0.99183–0.99183 | —–— |
| medium | pb99_safe/pb95 | path | 1 | 0.13618 | 0.1289 | 1.0564 | 1.0564–1.0564 | —–— |
| medium | quadtrait/pb95 | cold | 1 | 0.016147 | 0.016262 | 0.9929 | 0.9929–0.9929 | —–— |
| medium | quadtrait/pb95 | path | 1 | 0.12815 | 0.1289 | 0.99413 | 0.99413–0.99413 | —–— |
| wide | cadence1/pb95 | cold | 1 | 0.29583 | 0.20923 | 1.4139 | 1.4139–1.4139 | —–— |
| wide | cadence1/pb95 | path | 1 | 2.156 | 1.5701 | 1.3732 | 1.3732–1.3732 | —–— |
| wide | cadence20/pb95 | cold | 1 | 0.21001 | 0.20923 | 1.0037 | 1.0037–1.0037 | —–— |
| wide | cadence20/pb95 | path | 1 | 1.7229 | 1.5701 | 1.0973 | 1.0973–1.0973 | —–— |
| wide | candidate/apg | cold | 1 | 0.19139 | 0.31734 | 0.60309 | 0.60309–0.60309 | —–— |
| wide | candidate/apg | path | 1 | 1.3564 | 2.4849 | 0.54586 | 0.54586–0.54586 | —–— |
| wide | candidate/baseline | cold | 1 | 0.19139 | 0.22316 | 0.85762 | 0.85762–0.85762 | —–— |
| wide | candidate/baseline | path | 1 | 1.3564 | 1.5705 | 0.8637 | 0.8637–0.8637 | —–— |
| wide | candidate/guarded_final | cold | 1 | 0.19139 | 0.1988 | 0.9627 | 0.9627–0.9627 | —–— |
| wide | candidate/guarded_final | path | 1 | 1.3564 | 1.4317 | 0.94741 | 0.94741–0.94741 | —–— |
| wide | candidate/po95 | cold | 1 | 0.19139 | 0.22702 | 0.84304 | 0.84304–0.84304 | —–— |
| wide | candidate/po95 | path | 1 | 1.3564 | 1.6562 | 0.81899 | 0.81899–0.81899 | —–— |
| wide | candidate/py_admm | cold | 1 | 0.19139 | 0.71251 | 0.26861 | 0.26861–0.26861 | —–— |
| wide | candidate/py_admm | path | 1 | 1.3564 | 5.3069 | 0.2556 | 0.2556–0.2556 | —–— |
| wide | candidate/py_fista | cold | 1 | 0.19139 | 0.78532 | 0.2437 | 0.2437–0.2437 | —–— |
| wide | candidate/py_fista | path | 1 | 1.3564 | 5.4892 | 0.24711 | 0.24711–0.24711 | —–— |
| wide | coeffonly/pb95 | cold | 1 | 0.19763 | 0.20923 | 0.94458 | 0.94458–0.94458 | —–— |
| wide | coeffonly/pb95 | path | 1 | 1.4267 | 1.5701 | 0.90868 | 0.90868–0.90868 | —–— |
| wide | finalreuse/pb95 | cold | 1 | 0.20865 | 0.20923 | 0.99724 | 0.99724–0.99724 | —–— |
| wide | finalreuse/pb95 | path | 1 | 1.5783 | 1.5701 | 1.0053 | 1.0053–1.0053 | —–— |
| wide | guarded/pb95 | cold | 1 | 0.20672 | 0.20923 | 0.98803 | 0.98803–0.98803 | —–— |
| wide | guarded/pb95 | path | 1 | 1.4531 | 1.5701 | 0.92552 | 0.92552–0.92552 | —–— |
| wide | guarded_final/pb95 | cold | 1 | 0.1988 | 0.20923 | 0.95017 | 0.95017–0.95017 | —–— |
| wide | guarded_final/pb95 | path | 1 | 1.4317 | 1.5701 | 0.91187 | 0.91187–0.91187 | —–— |
| wide | pb95/baseline | cold | 1 | 0.20923 | 0.22316 | 0.93757 | 0.93757–0.93757 | —–— |
| wide | pb95/baseline | path | 1 | 1.5701 | 1.5705 | 0.99975 | 0.99975–0.99975 | —–— |
| wide | pb99_safe/pb95 | cold | 1 | 0.21578 | 0.20923 | 1.0313 | 1.0313–1.0313 | —–— |
| wide | pb99_safe/pb95 | path | 1 | 1.66 | 1.5701 | 1.0573 | 1.0573–1.0573 | —–— |
| wide | quadtrait/pb95 | cold | 1 | 0.22395 | 0.20923 | 1.0703 | 1.0703–1.0703 | —–— |
| wide | quadtrait/pb95 | path | 1 | 1.5858 | 1.5701 | 1.01 | 1.01–1.01 | —–— |

Full cold fractions, cached workloads, per-input ratios, adverse results, memory by stage, counters and profiles are in the adjacent CSV/JSON records. Cumulative allocated bytes and whole-process peak RSS measure different quantities; neither substitutes for timing-stage memory.

Profiles absent, empty or buffer-truncated: 0. Public/cached point checks with missing or failing certificates/objective mismatch: 0. Bitwise equal public/cached coefficients: 330/330.

The .99/L step, certificate cadence 1/20, quadratic trait and coefficient-only variants are controlled experiments. Their performance does not itself justify changing production defaults. APG remains the package default; production PANOC uses .95/L and cadence 10. The near-fit cancellation guard and Float32 arithmetic are covered by the separate release/LTS correctness study.

This script reads saved outputs only. It performs no generation, fitting or timing reruns, and does not overwrite failed primary receipts. Final adoption/default decisions require interpretation of all cold/path cases and failures.
