####################################
#
# losses of coordinate descent
#
####################################

# The built-in losses are models of ProximalSolvers (ProximalSolvers.CDModel), the loss
# together with the cache that makes a coordinate step cheap; the constructors
# keep the names and the conventions of the earlier versions of this package.

"""
    CDLeastSquaresLoss(y, X; intercept=false)

The least squares loss `f(β) = ‖y - Xβ‖² / (2n)`, as the model of ProximalSolvers
for `(1/n) * LeastSquaresLoss(y, X)` (see `ProximalSolvers.cdmodel`). It caches the
residuals `r = y - Xβ`, so a coordinate update costs `O(n)`, and reads `X` and
`y` in place.

With `intercept`, the loss is minimized over an unpenalized intercept as well,
`f(β) = min_β₀ ‖y - β₀ - Xβ‖² / (2n)`, whose minimizer is `β₀ = ȳ - x̄'β` for
the column means `x̄` and the mean `ȳ` of `y`
(`ProximalSolvers.intercept(f, β)`). The columns and `y` are centered on the fly,
so `X` is not copied, and the residuals are `y - β₀ - Xβ`
(`ProximalSolvers.residuals(f)`).

A column that the loss does not depend on, a zero column or, with
`intercept`, a constant one, gets the minimizer of the penalty nearest zero.
`y` and `X` must not contain `NaN` or `Inf`.

On an `AtomIterate`, for the group lasso, a group `G` is updated at once, with
the largest eigenvalue of the centered `X[:, G]'X[:, G] / n` as the curvature.
"""
CDLeastSquaresLoss(y::AbstractVector, X::AbstractMatrix; intercept::Bool=false) =
  cdmodel((1 / size(X, 1)) * LeastSquaresLoss(y, X), nothing; intercept)

"""
    CDWeightedLSLoss(y, X, w)

The weighted least squares loss `f(β) = ∑ᵢ wᵢ (yᵢ - Xᵢ'β)² / (2n)`, as the
model of ProximalSolvers for `(1/n) * GLMLoss(ProximalBase.Squared(), y, X;
weights = w)`. It caches the residuals `r = y - Xβ` and the weighted squared
column norms.

`y`, `X` and `w` are read in place, so changing them changes the loss for the
next solve. They are checked for `NaN` or `Inf`
and the weights for negative entries only when the loss is built, so build it
from initialized buffers. A coefficient whose column does not enter the loss
(`∑ᵢ wᵢ Xᵢₖ² = 0`) goes to the minimizer of the penalty nearest zero.
"""
CDWeightedLSLoss(y::AbstractVector, X::AbstractMatrix, w::AbstractVector) =
  cdmodel((1 / size(X, 1)) * GLMLoss(ProximalBase.Squared(), y, X; weights = w), nothing)

"""
    CDSqrtLassoLoss(y, X; intercept=false)

The square-root lasso loss `f(β) = ‖y - Xβ‖`, as the model of ProximalSolvers for
`ProximalSolvers.SqrtLeastSquaresLoss(y, X)`. It caches the residuals
`r = y - Xβ` and the squared column norms. With `intercept`,
`f(β) = min_β₀ ‖y - β₀ - Xβ‖`, minimized by `β₀ = ȳ - x̄'β`; as in
[`CDLeastSquaresLoss`](@ref), the columns and `y` are centered on the fly.

This loss is not smooth where `r = 0`, so coordinate descent minimizes `f + g`
over a coordinate exactly instead of using a quadratic approximation. It takes
the penalty `NormL1` only.
"""
CDSqrtLassoLoss(y::AbstractVector, X::AbstractMatrix; intercept::Bool=false) =
  cdmodel(SqrtLeastSquaresLoss(y, X), nothing; intercept)

"""
    CDSqrtQuadraticLoss(A, b, c; check=true)

The square-root lasso loss from sufficient statistics,
`f(x) = √(x'Ax + 2b'x + c)`, with symmetric positive semidefinite `A` and a
nonnegative quadratic, as the model of ProximalSolvers for
`ProximalSolvers.SqrtQuadraticFunction(A, b, c; check)`. With `A = X'X/n`,
`b = -X'y/n` and `c = y'y/n` it is `‖y - Xx‖ / √n`, the loss of
[`CDSqrtLassoLoss`](@ref) divided by `√n`, without the data: it caches `Ax` and
the value of the quadratic, so a coordinate update costs `O(p)` instead of
`O(n)`, and checking a coordinate that does not move costs `O(1)`. It pays off
when n > p, and when many fits share `A`. It also solves the scaled lasso of one
variable on the others from their covariance matrix `S`: `A = S`,
`b = -S[:, j]` and `c = S[j, j]`, with an infinite penalty weight on coordinate
`j`, which keeps it at zero (see [`scaled_lasso!`](@ref)).

As for [`CDSqrtLassoLoss`](@ref), coordinate descent minimizes `f + g` over a
coordinate exactly, for `NormL1` only. `A`, `b` and `c` must not contain `NaN`
or `Inf`, and `A` must be symmetric; checking `A` costs `O(p²)`, as much as a
few passes, so `check = false` skips it when many losses share a checked `A`,
as the columns of a covariance matrix do. A dense `Matrix` `A` is used as it
is.
"""
CDSqrtQuadraticLoss(A::AbstractMatrix, b::AbstractVector, c::Real; check::Bool=true) =
  cdmodel(SqrtQuadraticFunction(A, b, c; check), nothing)

"""
    CDQuadraticLoss(A, b)

The quadratic `f(x) = x'Ax / 2 + b'x` with symmetric `A`, as the model of
ProximalSolvers for `QuadraticFunction(A, b)`. It caches `Ax`, so a coordinate
update costs `O(p)`. With `A = X'X/n` and `b = -X'y/n` it gives the same
minimizer as [`CDLeastSquaresLoss`](@ref).

A coordinate with `A[k, k] = 0`, which `f` does not depend on when `A` is
positive semidefinite, goes to the minimizer of the penalty nearest zero. `A`
and `b` must not contain `NaN` or `Inf`. A dense `Matrix` `A` is used as it
is, as in version 0.6; any other matrix is copied into one.

On an `AtomIterate`, for the group lasso, a group `G` is updated at once, with
the largest eigenvalue of `A[G, G]` as the curvature.
"""
function CDQuadraticLoss(A::AbstractMatrix, b::AbstractVector)
  issymmetric(A) || throw(ArgumentError("A must be symmetric"))
  cdmodel(QuadraticFunction(A, b), nothing)
end


####################################
#
# user-defined losses
#
####################################

"""
    CoordinateDifferentiableFunction

Supertype of user-defined smooth losses `f` that [`coordinate_descent!`](@ref)
can minimize. A subtype caches whatever it needs (for example residuals) to
make coordinate updates cheap, and implements

- `initialize!(f, x)`: set the cache for the iterate `x`
- `gradient(f, x, k)`: coordinate `k` of the gradient of `f` at `x`
- `num_coordinates(f)`: number of coordinates
- `descend_coordinate!(f, g, x, k)`: update coordinate `k` of `x` and the cache

and optionally `coordinate_scale(f, k)` and `response_scale(f)`, which make the
stopping rule independent of the units of the data (see [`CDOptions`](@ref)),
`full_gradient!(grad, f, x)`, a faster way to compute the whole gradient, and
`f(x)`, the value of `f` at `x` from the cache, which Anderson acceleration
needs (`anderson` in [`CDOptions`](@ref)). These functions are not exported;
extend them as `CoordinateDescent.initialize!` and so on. The four required
functions have no methods of their own, so a missing method raises a
`MethodError` that lists the methods that exist.

The penalty `g` enters only through `descend_coordinate!`. A loss whose step
ends with the proximal operator of `g` on coordinate `k`,
`ProximalBase.prox_coordinate!(x, g, k, γ)`, works with every separable penalty
of ProximalBase and with user-defined ones (see [`coordinate_descent!`](@ref)).

Coordinate descent runs on ProximalSolvers, which takes such a loss through a
model (`ProximalSolvers.CDModel`); a loss written for ProximalSolvers directly, as a
`CDModel`, is also accepted.
"""
abstract type CoordinateDifferentiableFunction end

"""
    initialize!(f, x)

Set the internal cache of `f` (for example the residuals) for the iterate `x`.
Called by [`coordinate_descent!`](@ref) before the first pass.
"""
function initialize! end

"""
    gradient(f, x, k)

Coordinate `k` of the gradient of `f` at `x`, computed from the cache of `f`,
which must be current for `x`.
"""
function gradient end

"""
    num_coordinates(f)

Number of coordinates (or blocks of coordinates) over which coordinate descent
iterates.
"""
function num_coordinates end

"""
    descend_coordinate!(f, g, x, k)

Update coordinate `k` of `x` to decrease `f(x) + g(x)`, and return the change
of the coordinate. The cache of `f` must be updated for the new `x`.
"""
function descend_coordinate! end

"""
    coordinate_scale(f, k)

The scale of coordinate `k` for the relative stopping rule (see `opt_tol` in
[`CDOptions`](@ref)): the change of `x[k]` is multiplied by it. Defaults to 1.
"""
coordinate_scale(f, k) = 1

"""
    response_scale(f)

The scale that `opt_tol` is multiplied by in the relative stopping rule (see
[`CDOptions`](@ref)). Defaults to 1.
"""
response_scale(f) = 1

"""
    full_gradient!(grad, f, x)

Write the gradient of `f` at `x` into `grad`, from the cache of `f`, which must
be current for `x`, and return `grad`. Used to find the largest useful penalty
level when `warm_start` is false. Defaults to `gradient(f, x, k)` for every
coordinate.
"""
function full_gradient!(grad, f, x)
  for k in eachindex(grad)
    grad[k] = gradient(f, x, k)
  end
  grad
end

# The model of ProximalSolvers for a user-defined loss: each coordinate step is the
# loss's descend_coordinate!, and the optional functions give the scales of the
# stopping rule, the value and the gradient
struct _LossModel{T, F<:CoordinateDifferentiableFunction} <: CDModel{T}
  f::F
end

_LossModel(f::CoordinateDifferentiableFunction, x) = _LossModel{float(eltype(x)), typeof(f)}(f)

function ProximalSolvers.initialize!(m::_LossModel, x)
  num_coordinates(m.f) == ncoordinates(x) || throw(DimensionMismatch(
    "the loss has $(num_coordinates(m.f)) coordinates and the iterate $(ncoordinates(x))"))
  initialize!(m.f, x)
  m
end

ProximalSolvers.coordinate_step!(m::_LossModel{T}, g, x::SparseIterate{T}, k::Int) where {T} =
  descend_coordinate!(m.f, g, x, k)
ProximalSolvers.coordinate_step!(m::_LossModel{T}, g, x::SymmetricSparseIterate{T}, k::Int) where {T} =
  descend_coordinate!(m.f, g, x, k)

ProximalSolvers.coordinate_scale(m::_LossModel{T}, x, k::Int) where {T} = T(coordinate_scale(m.f, k))
ProximalSolvers.response_scale(m::_LossModel{T}, x) where {T} = T(response_scale(m.f))

# the value from the cache when the loss is callable, NaN otherwise
ProximalSolvers.loss_value(m::_LossModel{T}, x) where {T} = applicable(m.f, x) ? T(m.f(x)) : T(NaN)

ProximalSolvers.gradient!(G::AbstractVector, m::_LossModel, x::SparseIterate) = full_gradient!(G, m.f, x)

# the gradient over the entries of the p × p matrix, from the coordinates of
# the lower triangle: λmax compares |G[r, c]| with the weight of (r, c), as
# |gradient(f, x, k)| was compared with the weight of coordinate k before
function ProximalSolvers.gradient!(G::AbstractMatrix, m::_LossModel, x::SymmetricSparseIterate)
  for k in 1:ncoordinates(x)
    r, c = tril_cartesian(x.p, k)
    G[r, c] = G[c, r] = gradient(m.f, x, k)
  end
  G
end
