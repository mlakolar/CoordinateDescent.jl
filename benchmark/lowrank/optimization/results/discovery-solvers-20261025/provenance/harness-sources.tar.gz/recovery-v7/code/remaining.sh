#!/bin/bash
# Downstream stages from comparison.sbatch, with corrected Python CLI aliases.
"$CD81_PARALLEL_BIN" -j2 --joblog results/recovery/r-component-joblog.tsv \
 'srun --exclusive --exact -N1 -n1 -c1 --mem=8G bash code/worker-v3.sh responses-{} r-component > results/main/responses-{}-r-component.log 2>&1' ::: 1 2 3 4 5
for rep in 1 2 3 4 5;do
 for name in responses wide;do
  for solver in cd_rank cd_nuclear cd_panoc ps_fista ps_admm pa_fista pa_panoc cd_sparse block_fista cd_sparse_api cd_sparse_fista cd_component component_fista;do
   printf '%s-%s julia %s\n' "$name" "$rep" "$solver"
  done
  for solver in before_rank before_nuclear before_sparse;do printf '%s-%s before %s\n' "$name" "$rep" "$solver";done
  for solver in scipy_rrr py_fista py_admm;do printf '%s-%s python %s\n' "$name" "$rep" "$solver";done
  for solver in r_rrr r_rrr_qr r_srrr;do printf '%s-%s r %s\n' "$name" "$rep" "$solver";done
  if [ "$name" = wide ];then printf '%s-%s r r_component\n' "$name" "$rep";fi
 done
done > memory-tasks.txt
"$CD81_PARALLEL_BIN" -j8 --colsep ' ' --joblog results/memory/joblog.tsv \
 'srun --exclusive --exact -N1 -n1 -c1 --mem=2G bash code/memory-v3.sh {1} {2} {3} > results/memory/{1}-{3}.log 2>&1' :::: memory-tasks.txt
"$CD81_PARALLEL_BIN" -j2 --joblog results/recovery/r-memory-joblog.tsv \
 'srun --exclusive --exact -N1 -n1 -c1 --mem=8G bash code/memory-v3.sh responses-{} r r_component > results/memory/responses-{}-r_component.log 2>&1' ::: 1 2 3 4 5
"$CD81_PARALLEL_BIN" -j8 --joblog results/adaptive/joblog.tsv \
 'srun --exclusive --exact -N1 -n1 -c1 --mem=2G "$JULIA" --startup-file=no --project=env-1.13.2 code/adaptive.jl {} > results/adaptive/rep-{}.log 2>&1' ::: 1 2 3 4 5
srun --exclusive --exact -N1 -n1 -c1 --mem=2G "$PYTHON" code/analyze-v3.py
"$PYTHON" code/collect-v3.py
