####################################
#
#  Separable functions f(x) = Σᵢ fᵢ(xᵢ)
#
####################################

"""
    SeparableFunction

The supertype of the separable functions `f(x) = Σᵢ fᵢ(xᵢ)`, and the way to add
one of your own. A subtype implements, for the entry with linear index `i`,

- [`prox_entry`](@ref)`(f, v, i, γ)`: the proximal operator of `γfᵢ` at the
  scalar `v`;
- [`value_entry`](@ref)`(f, v, i)`: the value `fᵢ(v)`.

From these it gets the value `f(x)`, [`prox!`](@ref) and
[`value_and_prox!`](@ref) on any array, and [`prox_coordinate!`](@ref) on the
three iterates. Declare [`iszeropreserving`](@ref) when `fᵢ(0) = 0` and the
proximal operator maps 0 to 0; then the value and the proximal operator on a
sparse iterate touch only its stored entries. `isseparable` and `isproximable`
are true; declare `isconvex` when it holds.

# Example

```julia
struct WeightedSquare <: SeparableFunction            # Σᵢ wᵢ xᵢ² / 2
    w::Vector{Float64}
end
ProximalBase.value_entry(f::WeightedSquare, v, i) = f.w[i] * v^2 / 2
ProximalBase.prox_entry(f::WeightedSquare, v, i, γ) = v / (1 + γ * f.w[i])
ProximalBase.iszeropreserving(::WeightedSquare) = true
ProximalBase.isconvex(::Type{WeightedSquare}) = true
```
"""
abstract type SeparableFunction <: AbstractFunction end

isseparable(::Type{<:SeparableFunction}) = true
isproximable(::Type{<:SeparableFunction}) = true

"""
    value_entry(f, v, i)

For a [`SeparableFunction`](@ref) `f(x) = Σᵢ fᵢ(xᵢ)`, the value `fᵢ(v)` of the
term of entry `i` at the scalar `v`. `i` is a linear index of the array, as in
[`prox_entry`](@ref).
"""
function value_entry end

"""
    iszeropreserving(f)

Whether the separable function `f` has `fᵢ(0) = 0` and maps 0 to 0 by its
proximal operator, `prox_entry(f, 0, i, γ) = 0`, for every entry `i` and step
`γ`, as norms and most penalties do. Then the value and the proximal operator
on a sparse iterate touch only its stored entries. It is `false` unless a
function declares it, and it is a property of the function, not of its type:
the bounds of an `IndBox` may exclude zero.
"""
iszeropreserving(::SeparableFunction) = false

(f::SeparableFunction)(x::AbstractArray) = _value_sep(f, x)
prox!(y::AbstractArray, f::SeparableFunction, x::AbstractArray, γ::Real) = _prox_sep!(y, f, x, γ)
value_and_prox!(y::AbstractArray, f::SeparableFunction, x::AbstractArray, γ::Real) = _value_and_prox_sep!(y, f, x, γ)

# the value, entry by entry over the dense array
function _value_dense(f, x::AbstractArray)
  T = float(eltype(x))
  s = zero(T)
  @inbounds @simd for i in eachindex(IndexLinear(), x)
    s += convert(T, value_entry(f, x[i], i))
  end
  s
end

_value_sep(f, x::AbstractArray) = (_checkparams(f, x); _value_dense(f, x))

function _value_sep(f, x::SparseIterate)
  _checkparams(f, x)
  iszeropreserving(f) || return _value_dense(f, x)
  T = float(eltype(x))
  s = zero(T)
  @inbounds for k in 1:x.nnz
    s += convert(T, value_entry(f, x.nzval[k], x.nzval2ind[k]))
  end
  s
end

# an off-diagonal coordinate is the entries (r, c) and (c, r)
function _value_sep(f, x::SymmetricSparseIterate)
  _checkparams(f, x)
  iszeropreserving(f) || return _value_dense(f, x)
  T = float(eltype(x))
  p = x.p
  s = zero(T)
  @inbounds for k in 1:x.nnz
    r, c = tril_cartesian(p, x.nzval2ind[k])
    v = x.nzval[k]
    s += convert(T, value_entry(f, v, (c - 1) * p + r))
    r == c || (s += convert(T, value_entry(f, v, (r - 1) * p + c)))
  end
  s
end

function _value_sep(f, x::AtomIterate)
  _checkparams(f, x)
  iszeropreserving(f) || return _value_dense(f, x)
  T = float(eltype(x))
  s = zero(T)
  @inbounds for a in 1:x.nactive, i in x.groups[x.active[a]]
    s += convert(T, value_entry(f, x.storage[i], i))
  end
  s
end

# the proximal operator, entry by entry; y may be x
_prox_sep!(y::AbstractArray, f, x::AbstractArray, γ::Union{Real, AbstractArray}) = _prox_sep_dense!(y, f, x, γ)

function _prox_sep_dense!(y::AbstractArray, f, x::AbstractArray, γ)
  _checksize(y, x)
  _checkparams(f, x)
  _checkparam(γ, x)
  T = eltype(y)
  @inbounds for i in eachindex(IndexLinear(), y, x)
    y[i] = convert(T, prox_entry(f, x[i], i, _entry(γ, i)))
  end
  y
end

# on sparse iterates, only the stored entries when f preserves zeros; as for a
# dense array, an entry stored in y stays stored, possibly as a zero
function _prox_sep!(y::SparseIterate, f, x::SparseIterate, γ::Union{Real, AbstractArray})
  _checksize(y, x)
  _checkparams(f, x)
  _checkparam(γ, x)
  iszeropreserving(f) || return _prox_sep_dense!(y, f, x, γ)
  T = eltype(y)
  if y !== x
    @inbounds for k in 1:y.nnz
      y.nzval[k] = zero(T)
    end
  end
  @inbounds for k in 1:x.nnz
    i = x.nzval2ind[k]
    _setstored!(y, convert(T, prox_entry(f, x.nzval[k], i, _entry(γ, i))), i)
  end
  y
end

# each coordinate (an entry of the lower triangle) once, and from a
# SymmetricSparseIterate only its stored coordinates when f preserves zeros
function _prox_sep!(y::SymmetricSparseIterate, f, x::AbstractMatrix, γ::Union{Real, AbstractArray})
  _checksize(y, x)
  _checkparams(f, x)
  _checkparam(γ, x)
  T = eltype(y)
  p = y.p
  if x isa SymmetricSparseIterate && iszeropreserving(f)
    if y !== x                       # as for a SparseIterate, y keeps its stored entries
      @inbounds for k in 1:y.nnz
        y.nzval[k] = zero(T)
      end
    end
    @inbounds for k in 1:x.nnz
      i = x.nzval2ind[k]
      r, c = tril_cartesian(p, i)
      j = (c - 1) * p + r
      _setstored!(y, convert(T, prox_entry(f, x.nzval[k], j, _entry(γ, j))), i)
    end
    return y
  end
  @inbounds for c in 1:p, r in c:p
    j = (c - 1) * p + r
    _setstored!(y, convert(T, prox_entry(f, x[r, c], j, _entry(γ, j))), tril_index(p, r, c))
  end
  y
end

# the proximal operator, then the value at the result: two vectorized passes are
# several times faster than one that stores and sums, which does not vectorize;
# an indicator function is 0 at its projection
_value_and_prox_sep!(y::AbstractArray, f, x::AbstractArray, γ::Union{Real, AbstractArray}) =
  _isindicator(f) ? (_prox_sep!(y, f, x, γ); zero(float(eltype(y)))) : _value_sep(f, _prox_sep!(y, f, x, γ))

_restrict_entries(w::Union{Nothing, Real}, ::AbstractVector{<:Integer}) = w
_restrict_entries(w::AbstractArray, S::AbstractVector{<:Integer}) = w[S]

####################################
#  ℓ1 norm
####################################

"""
    NormL1(λ0 = 1)
    NormL1(λ0, w)

The weighted ℓ1 norm `f(x) = λ0 Σᵢ wᵢ |xᵢ|`, with all `wᵢ = 1` when `w` is
omitted. Its proximal operator is entry-wise soft thresholding
([`shrink`](@ref)). Separable, so [`prox_coordinate!`](@ref) updates any
coordinate, and on a sparse iterate the value and the proximal operator touch
only the stored entries. On a [`SymmetricSparseIterate`](@ref) the weights are a
`p × p` matrix (or anything indexed by the linear indices of one), as for a
dense matrix.
"""
struct NormL1{T<:Real, W<:Union{Nothing, AbstractArray}} <: SeparableFunction
  λ0::T
  w::W

  function NormL1{T, W}(λ0::T, w::W) where {T<:Real, W<:Union{Nothing, AbstractArray}}
    _checknonneg("λ0", λ0)
    _checknonneg("the weights", w)
    new{T, W}(λ0, w)
  end
end
NormL1(λ0::Real = 1, w::Union{Nothing, AbstractArray} = nothing) = NormL1{typeof(λ0), typeof(w)}(λ0, w)

isconvex(::Type{<:NormL1}) = true
iszeropreserving(::NormL1) = true
_checkparams(f::NormL1, x) = (_checkparam(f.w, x); true)

Base.@propagate_inbounds value_entry(f::NormL1, v::Real, i::Integer) = f.λ0 * _entry(f.w, i) * abs(v)
Base.@propagate_inbounds prox_entry(f::NormL1, v::T, i::Integer, γ::Real) where {T<:Real} =
  shrink(v, convert(float(T), γ * f.λ0 * _entry(f.w, i)))

kkt_violation(f::NormL1, g::AbstractArray, i::Integer) = abs(g[i]) - f.λ0 * _entry(f.w, i)
restrict(f::NormL1, S::AbstractVector{<:Integer}) = NormL1(f.λ0, _restrict_entries(f.w, S))

# without weights, Base's vectorized sum (a sum with init takes a slow sequential path)
function (f::NormL1{<:Real, Nothing})(x::DenseArray{<:AbstractFloat})
  T = float(eltype(x))
  convert(T, f.λ0) * sum(abs, x)
end

####################################
#  ℓ1 norm on the nonnegative orthant
####################################

"""
    NormL1Nonneg(λ0 = 1)
    NormL1Nonneg(λ0, w)

The weighted ℓ1 norm restricted to the nonnegative orthant:
`f(x) = λ0 Σᵢ wᵢ xᵢ` for `x ≥ 0`, and `Inf` otherwise, the penalty of the
nonnegative lasso. Its proximal operator is `max(x - γλ0w, 0)`.
"""
struct NormL1Nonneg{T<:Real, W<:Union{Nothing, AbstractArray}} <: SeparableFunction
  λ0::T
  w::W

  function NormL1Nonneg{T, W}(λ0::T, w::W) where {T<:Real, W<:Union{Nothing, AbstractArray}}
    _checknonneg("λ0", λ0)
    _checknonneg("the weights", w)
    new{T, W}(λ0, w)
  end
end
NormL1Nonneg(λ0::Real = 1, w::Union{Nothing, AbstractArray} = nothing) = NormL1Nonneg{typeof(λ0), typeof(w)}(λ0, w)

isconvex(::Type{<:NormL1Nonneg}) = true
iszeropreserving(::NormL1Nonneg) = true
_checkparams(f::NormL1Nonneg, x) = (_checkparam(f.w, x); true)

Base.@propagate_inbounds function value_entry(f::NormL1Nonneg, v::T, i::Integer) where {T<:Real}
  S = float(T)
  v >= -_tol(S) ? f.λ0 * _entry(f.w, i) * max(v, zero(T)) : S(Inf)
end
Base.@propagate_inbounds prox_entry(f::NormL1Nonneg, v::T, i::Integer, γ::Real) where {T<:Real} =
  max(v - convert(float(T), γ * f.λ0 * _entry(f.w, i)), zero(float(T)))

# moving up from zero decreases the objective when -gᵢ exceeds λ0 wᵢ
kkt_violation(f::NormL1Nonneg, g::AbstractArray, i::Integer) = -g[i] - f.λ0 * _entry(f.w, i)
restrict(f::NormL1Nonneg, S::AbstractVector{<:Integer}) = NormL1Nonneg(f.λ0, _restrict_entries(f.w, S))

####################################
#  elastic net
####################################

"""
    ElasticNet(λ1, λ2)
    ElasticNet(λ1, λ2, w)

The elastic-net penalty `f(x) = λ1 Σᵢ wᵢ |xᵢ| + (λ2/2) ‖x‖²`, with all `wᵢ = 1`
when `w` is omitted. Its proximal operator is
`shrink(x, γλ1w) / (1 + γλ2)`.
"""
struct ElasticNet{T<:Real, W<:Union{Nothing, AbstractArray}} <: SeparableFunction
  λ1::T
  λ2::T
  w::W

  function ElasticNet{T, W}(λ1::T, λ2::T, w::W) where {T<:Real, W<:Union{Nothing, AbstractArray}}
    _checknonneg("λ1", λ1)
    _checknonneg("λ2", λ2)
    _checknonneg("the weights", w)
    new{T, W}(λ1, λ2, w)
  end
end
function ElasticNet(λ1::Real, λ2::Real, w::Union{Nothing, AbstractArray} = nothing)
  λ1, λ2 = promote(λ1, λ2)
  ElasticNet{typeof(λ1), typeof(w)}(λ1, λ2, w)
end

isconvex(::Type{<:ElasticNet}) = true
iszeropreserving(::ElasticNet) = true
_checkparams(f::ElasticNet, x) = (_checkparam(f.w, x); true)

Base.@propagate_inbounds value_entry(f::ElasticNet, v::Real, i::Integer) = f.λ1 * _entry(f.w, i) * abs(v) + f.λ2 * abs2(v) / 2
Base.@propagate_inbounds function prox_entry(f::ElasticNet, v::T, i::Integer, γ::Real) where {T<:Real}
  S = float(T)
  shrink(v, convert(S, γ * f.λ1 * _entry(f.w, i))) / (1 + convert(S, γ * f.λ2))
end

kkt_violation(f::ElasticNet, g::AbstractArray, i::Integer) = abs(g[i]) - f.λ1 * _entry(f.w, i)
restrict(f::ElasticNet, S::AbstractVector{<:Integer}) = ElasticNet(f.λ1, f.λ2, _restrict_entries(f.w, S))

####################################
#  box
####################################

"""
    IndBox(l, u)

The indicator of the box `{x : l ≤ x ≤ u}`: `0` inside and `Inf` outside. The
bounds are scalars or arrays of the size of `x`, and may be infinite. Its
proximal operator is the projection `clamp.(x, l, u)`.
"""
struct IndBox{L<:Union{Real, AbstractArray}, U<:Union{Real, AbstractArray}} <: SeparableFunction
  l::L
  u::U
  zp::Bool          # l ≤ 0 ≤ u, so that zero is feasible and its own projection

  function IndBox{L, U}(l::L, u::U) where {L<:Union{Real, AbstractArray}, U<:Union{Real, AbstractArray}}
    all(l .<= u) || throw(ArgumentError("the lower bounds must not exceed the upper bounds"))
    new{L, U}(l, u, all(l .<= 0) && all(u .>= 0))
  end
end
IndBox(l::Union{Real, AbstractArray}, u::Union{Real, AbstractArray}) = IndBox{typeof(l), typeof(u)}(l, u)

"""
    IndBallLinf(r)

The indicator of the ℓ∞ ball `{x : maxᵢ |xᵢ| ≤ r}`, the box [`IndBox`](@ref)`(-r, r)`.
"""
IndBallLinf(r::Real) = (_checknonneg("r", r); IndBox(-r, r))

isconvex(::Type{<:IndBox}) = true
iszeropreserving(f::IndBox) = f.zp
_checkparams(f::IndBox, x) = (_checkparam(f.l, x); _checkparam(f.u, x); true)

_isindicator(::Type{<:IndBox}) = true

# feasibility with a branch-free loop that vectorizes, then the value
function _value_dense(f::IndBox, x::AbstractArray)
  T = float(eltype(x))
  t = _tol(T)
  ok = true
  @inbounds @simd for i in eachindex(IndexLinear(), x)
    l, u, v = _entry(f.l, i), _entry(f.u, i), x[i]
    ok &= (v >= l - t * max(one(T), abs(l))) & (v <= u + t * max(one(T), abs(u)))
  end
  ok ? zero(T) : T(Inf)
end

Base.@propagate_inbounds function value_entry(f::IndBox, v::T, i::Integer) where {T<:Real}
  S = float(T)
  l, u = _entry(f.l, i), _entry(f.u, i)
  t = _tol(S)
  (v >= l - t * max(one(S), abs(l)) && v <= u + t * max(one(S), abs(u))) ? zero(S) : S(Inf)
end
# the bounds in the type of the result: a clamp between integer bounds compares
# a float with an integer exactly, which does not vectorize
Base.@propagate_inbounds function prox_entry(f::IndBox, v::T, i::Integer, ::Real) where {T<:Real}
  S = float(T)
  clamp(convert(S, v), convert(S, _entry(f.l, i)), convert(S, _entry(f.u, i)))
end

# from zero, the objective decreases upward at rate -gᵢ if u > 0, and downward
# at rate gᵢ if l < 0; zero must be feasible
function kkt_violation(f::IndBox, g::AbstractArray, i::Integer)
  T = float(eltype(g))
  up = _entry(f.u, i) > 0 ? -g[i] : T(-Inf)
  down = _entry(f.l, i) < 0 ? g[i] : T(-Inf)
  max(up, down)
end
restrict(f::IndBox, S::AbstractVector{<:Integer}) = IndBox(_restrict_entries(f.l, S), _restrict_entries(f.u, S))

"""
    IndNonnegative()

The indicator of the nonnegative orthant `{x : x ≥ 0}`. Its proximal operator is
`max.(x, 0)`.
"""
struct IndNonnegative <: SeparableFunction end

isconvex(::Type{IndNonnegative}) = true
iszeropreserving(::IndNonnegative) = true

_isindicator(::Type{IndNonnegative}) = true
_value_dense(::IndNonnegative, x::AbstractArray) =
  (T = float(eltype(x)); isempty(x) || minimum(x) >= -_tol(T) ? zero(T) : T(Inf))

@inline value_entry(::IndNonnegative, v::T, ::Integer) where {T<:Real} =
  v >= -_tol(float(T)) ? zero(float(T)) : float(T)(Inf)
@inline prox_entry(::IndNonnegative, v::T, ::Integer, ::Real) where {T<:Real} = max(float(v), zero(float(T)))
kkt_violation(::IndNonnegative, g::AbstractArray, i::Integer) = -g[i]
restrict(f::IndNonnegative, ::AbstractVector{<:Integer}) = f

####################################
#  ℓ0 penalty
####################################

"""
    NormL0(λ = 1)

The ℓ0 penalty `f(x) = λ ⋅ #{i : xᵢ ≠ 0}`, nonconvex. Its proximal operator is
hard thresholding: `xᵢ` is kept when `|xᵢ| > √(2γλ)` and set to zero otherwise.
"""
struct NormL0{T<:Real} <: SeparableFunction
  λ::T

  NormL0{T}(λ::T) where {T<:Real} = (_checknonneg("λ", λ); new{T}(λ))
end
NormL0(λ::Real = 1) = NormL0{typeof(λ)}(λ)

iszeropreserving(::NormL0) = true

Base.@propagate_inbounds value_entry(f::NormL0, v::T, ::Integer) where {T<:Real} = iszero(v) ? zero(float(T)) : convert(float(T), f.λ)
Base.@propagate_inbounds prox_entry(f::NormL0, v::T, ::Integer, γ::Real) where {T<:Real} =
  abs2(v) > 2 * γ * f.λ ? float(v) : zero(float(T))
restrict(f::NormL0, ::AbstractVector{<:Integer}) = f

####################################
#  MCP and SCAD
####################################

"""
    MCP(λ, a = 3)

The minimax concave penalty of Zhang (2010), nonconvex:
`fᵢ(t) = λ|t| - t²/(2a)` for `|t| ≤ aλ` and `aλ²/2` beyond, for `a > 0`. It
matches the ℓ1 penalty at zero and stops penalizing large entries. For a step
`γ < a` its proximal operator is firm thresholding; for larger steps it is the
global minimizer of the nonconvex problem.
"""
struct MCP{T<:Real} <: SeparableFunction
  λ::T
  a::T

  function MCP{T}(λ::T, a::T) where {T<:Real}
    _checknonneg("λ", λ)
    a > 0 || throw(ArgumentError("a must be positive, got $a"))
    new{T}(λ, a)
  end
end
MCP(λ::Real, a::Real = 3) = (p = promote(λ, a); MCP{typeof(p[1])}(p...))

iszeropreserving(::MCP) = true

Base.@propagate_inbounds function value_entry(f::MCP, v::T, ::Integer) where {T<:Real}
  S = float(T)
  λ, a, t = S(f.λ), S(f.a), abs(S(v))
  t <= a * λ ? λ * t - t^2 / (2a) : a * λ^2 / 2
end

Base.@propagate_inbounds function prox_entry(f::MCP, v::T, i::Integer, γ::Real) where {T<:Real}
  S = float(T)
  λ, a, s, t = S(f.λ), S(f.a), S(γ), abs(S(v))
  if s < a
    t <= s * λ && return zero(S)
    t > a * λ && return S(v)
    return sign(S(v)) * (t - s * λ) / (1 - s / a)
  end
  # concave between 0 and aλ: the minimizer is 0 or the largest candidate
  u = max(t, a * λ)
  h(z) = (z - t)^2 / (2s) + value_entry(f, z, i)
  h(u) < h(zero(S)) ? sign(S(v)) * u : zero(S)
end

kkt_violation(f::MCP, g::AbstractArray, i::Integer) = abs(g[i]) - f.λ
restrict(f::MCP, ::AbstractVector{<:Integer}) = f

"""
    SCAD(λ, a = 3.7)

The smoothly clipped absolute deviation penalty of Fan and Li (2001),
nonconvex: `fᵢ(t) = λ|t|` for `|t| ≤ λ`,
`(2aλ|t| - t² - λ²) / (2(a - 1))` for `λ < |t| ≤ aλ`, and `λ²(a + 1)/2` beyond,
for `a > 2`. For a step `γ < a - 1` its proximal operator is the SCAD
thresholding rule; for larger steps it is the global minimizer of the nonconvex
problem.
"""
struct SCAD{T<:Real} <: SeparableFunction
  λ::T
  a::T

  function SCAD{T}(λ::T, a::T) where {T<:Real}
    _checknonneg("λ", λ)
    a > 2 || throw(ArgumentError("a must exceed 2, got $a"))
    new{T}(λ, a)
  end
end
SCAD(λ::Real, a::Real = 3.7) = (p = promote(λ, a); SCAD{typeof(p[1])}(p...))

iszeropreserving(::SCAD) = true

Base.@propagate_inbounds function value_entry(f::SCAD, v::T, ::Integer) where {T<:Real}
  S = float(T)
  λ, a, t = S(f.λ), S(f.a), abs(S(v))
  t <= λ && return λ * t
  t <= a * λ && return (2a * λ * t - t^2 - λ^2) / (2 * (a - 1))
  λ^2 * (a + 1) / 2
end

Base.@propagate_inbounds function prox_entry(f::SCAD, v::T, i::Integer, γ::Real) where {T<:Real}
  S = float(T)
  λ, a, s, t = S(f.λ), S(f.a), S(γ), abs(S(v))
  if s < a - 1
    t <= (1 + s) * λ && return shrink(S(v), s * λ)
    t > a * λ && return S(v)
    return sign(S(v)) * ((a - 1) * t - s * a * λ) / (a - 1 - s)
  end
  # concave on [λ, aλ]: compare the minimizers of the three pieces
  h(z) = (z - t)^2 / (2s) + value_entry(f, z, i)
  best, hb = zero(S), h(zero(S))
  for z in (min(max(t - s * λ, zero(S)), λ), a * λ, max(t, a * λ))
    hz = h(z)
    hz < hb && ((best, hb) = (z, hz))
  end
  sign(S(v)) * best
end

kkt_violation(f::SCAD, g::AbstractArray, i::Integer) = abs(g[i]) - f.λ
restrict(f::SCAD, ::AbstractVector{<:Integer}) = f
